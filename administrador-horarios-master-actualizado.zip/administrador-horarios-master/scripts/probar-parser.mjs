// Script de prueba por consola para el parser, SIN necesidad de levantar
// el navegador ni la app Astro/Vue (usa solo el módulo puro `parser.ts`,
// que no toca localStorage).
//
// Requiere `tsx` (para poder importar un .ts directamente en Node):
//   npm install -D tsx
//
// Uso:
//   npx tsx scripts/probar-parser.mjs ruta/al/archivo.txt
//
// Si no se pasa ruta, lee un texto de ejemplo embebido más abajo.

import { readFileSync } from 'node:fs'
import { parsearTexto } from '../src/library/parser.ts'

const rutaArchivo = process.argv[2]

const textoEjemplo = `FORMULACION Y EVALUACION DE PROYECTOS
A - Juan Carlos Torreblanca
MIÉRCOLES, 11:30 - 13:10 (2 horas)
JUEVES, 10:40 - 13:10 (3 horas)
VIERNES, 07:00 - 08:40 (2 horas)

AUTOMATIZACION INDUSTRIAL
A - Elio Cruz Santander
LUNES, 07:00 - 08:40 (2 horas)
MARTES, 07:00 - 08:40 (2 horas)
A - Manuel Canaza Mazco
LUNES, 19:20 - 21:00 (2 horas) (Sala de Cómputo)`

const texto = rutaArchivo ? readFileSync(rutaArchivo, 'utf-8') : textoEjemplo

const resultado = parsearTexto(texto)

console.log(`\nClases: ${resultado.clases.length} | Grupos: ${resultado.grupos.length} | Bloques: ${resultado.bloques.length}\n`)

for (const clase of resultado.clases) {
    console.log(`\n📘 ${clase.nombre}`)
    for (const grupo of resultado.grupos.filter(g => g.clase === clase.id)) {
        console.log(`   👤 ${grupo.nombre}`)
        for (const bloque of resultado.bloques.filter(b => b.grupo === grupo.id)) {
            console.log(`      • día=${bloque.día} inicio=${bloque.inicio} final=${bloque.final}`)
        }
    }
}

if (resultado.errores.length > 0) {
    console.log(`\n⚠️  ${resultado.errores.length} advertencia(s)/error(es):\n`)
    for (const error of resultado.errores) {
        const prefijo = error.línea > 0 ? `Línea ${error.línea}` : 'General'
        console.log(`   [${prefijo}] ${error.mensaje}`)
    }
} else {
    console.log('\n✅ Sin advertencias.')
}

console.log('\n--- JSON completo ---')
console.log(JSON.stringify(resultado, null, 2))

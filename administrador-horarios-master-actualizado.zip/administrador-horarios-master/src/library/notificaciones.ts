import { atom } from "nanostores"
import { v4 as uuid } from "uuid"

export const notificaciones = atom<Notificación[]>([])

export function agregarNotificación(tipo: Notificación["tipo"], mensaje: string) {
    notificaciones.set([{ id: uuid(), tipo, mensaje }, ...notificaciones.get()])
}

export function eliminarNotificacion(id: string) {
    const nuevasNotificaciones = notificaciones.get().filter(notificación => notificación.id !== id)

    notificaciones.set([...nuevasNotificaciones])
}
/**
 * PARSER DE TEXTO PLANO (CLASE → GRUPO → BLOQUE)
 * ================================================
 *
 * Módulo PURO: no toca `localStorage` ni los stores de nanostores, así que
 * se puede importar y probar tanto en el navegador como en Node/CLI (ver
 * `scripts/probar-parser.mjs`). La integración con los stores persistentes
 * de la app vive en `./importador.ts`.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * FORMATO DE ENTRADA ESPERADO
 * ─────────────────────────────────────────────────────────────────────────
 *
 *   NOMBRE DEL CURSO
 *   A - Nombre del Docente
 *   LUNES, 07:00 - 08:40 (2 horas)
 *   MARTES, 07:00 - 08:40 (2 horas)
 *   B - Otro Docente
 *   LUNES, 19:20 - 21:00 (2 horas) (Sala de Cómputo)
 *
 *   OTRO CURSO (E)
 *   A - (Docente por asignar)
 *   MIÉRCOLES, 07:00 - 09:40 (3 horas)
 *
 * ─────────────────────────────────────────────────────────────────────────
 * SUPUESTOS DOCUMENTADOS (léelos antes de usar el parser con otros formatos)
 * ─────────────────────────────────────────────────────────────────────────
 *
 * 1. Cada CLASE inicia un nuevo "párrafo": la primera línea no vacía luego
 *    de una línea en blanco (o la primera línea del archivo) es el nombre
 *    del curso. Esto es exactamente lo que produce este mismo generador al
 *    exportar (ver `formatoBloque` en `registrador/index.vue`), y es el
 *    formato que yo mismo generé en la respuesta anterior.
 * 2. Dentro de un párrafo, cualquier línea que calce con el patrón de
 *    BLOQUE (día + rango horario + duración) se adjunta al GRUPO vigente.
 * 3. Cualquier otra línea dentro del párrafo (que no sea decorativa) se
 *    interpreta como un nuevo GRUPO: `<identificador> - <docente>`. Si no
 *    hay separador " - ", toda la línea se toma como nombre del docente y
 *    se genera un identificador de grupo automático (A, B, C…).
 * 4. Líneas puramente decorativas (`====`, `----`, `****`, etc., como los
 *    separadores "GRUPO A" que usé para organizar el archivo anterior) se
 *    ignoran y no interrumpen el párrafo actual.
 * 5. Los horarios están restringidos a los 16 bloques fijos de 50 minutos
 *    que ya usa el generador (`horasInicio` / `horasFinal` en
 *    `organizador.ts`, Lunes–Viernes). Un horario que no calce EXACTO con
 *    esos límites se reporta como error (no se aproxima en automático,
 *    para no correr el horario silenciosamente) — el mensaje de error
 *    sugiere el bloque más cercano.
 * 6. Docente vacío o literal "(Docente por asignar)" se preserva tal cual
 *    (el modelo de datos no distingue "sin asignar" de un nombre normal,
 *    es solo texto libre en `Grupo.nombre`).
 */

import { v4 as uuid } from 'uuid'
import { díasSemana, horasInicio, horasFinal } from './organizador'

// ───────────────────────────── TIPOS DE SALIDA ─────────────────────────────

export type ErrorParseo = {
    línea: number
    contenido: string
    mensaje: string
}

export type ResultadoParseo = {
    clases: Clase[]
    grupos: Grupo[]
    bloques: Bloque[]
    errores: ErrorParseo[]
}

// ────────────────────────────── CONSTANTES ─────────────────────────────────

const PALETA_COLORES = ['#5865f2', '#eb459e', '#57f287', '#fee75c', '#ed4245', '#3ba55d', '#faa61a', '#9b59b6']

const MAPA_DÍAS: Record<string, number> = {
    lunes: 0,
    martes: 1,
    miercoles: 2, // sin tilde (normalizado)
    jueves: 3,
    viernes: 4,
}

// Línea puramente decorativa: "======", "--- Grupo A ---", "*** foo ***", etc.
const RE_DECORATIVA = /^[=\-_*#~]{3,}.*$|^.*[=\-_*#~]{3,}$/

// "LUNES, 07:00 - 08:40 (2 horas)" u "... (2 horas) (Sala de Cómputo)"
// Nota: el "día" se captura de forma laxa (cualquier texto antes de la coma)
// a propósito, para que un día inválido (ej. "SABADO") SÍ caiga en esta rama
// y se reporte como error de bloque, en lugar de terminar mal-interpretado
// como una línea de GRUPO.
const RE_BLOQUE = /^([^,]+?)\s*,\s*(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*\(\s*(\d+)\s*horas?\s*\)\s*(?:\(([^)]+)\))?\s*$/i

// "A - Juan Carlos Torreblanca" / "A - (Docente por asignar)"
const RE_GRUPO = /^(.+?)\s*[-–]\s*(.+)$/

// ─────────────────────────────── UTILIDADES ────────────────────────────────

function normalizar(texto: string): string {
    return texto
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '') // quita tildes
        .trim()
        .toLowerCase()
}

function validarHora(hora: string): boolean {
    const [h, m] = hora.split(':').map(Number)
    return Number.isInteger(h) && Number.isInteger(m) && h >= 0 && h <= 23 && m >= 0 && m <= 59
}

function bloqueMásCercano(lista: readonly string[], hora: string): string {
    const [h, m] = hora.split(':').map(Number)
    const minutos = h * 60 + m

    let mejor = lista[0]
    let mejorDif = Infinity

    for (const candidato of lista) {
        const [ch, cm] = candidato.split(':').map(Number)
        const dif = Math.abs(ch * 60 + cm - minutos)
        if (dif < mejorDif) {
            mejorDif = dif
            mejor = candidato
        }
    }

    return mejor
}

function colorPara(índice: number): string {
    return PALETA_COLORES[índice % PALETA_COLORES.length]
}

// ────────────────────────────────── PARSER ─────────────────────────────────

/**
 * Parsea texto plano CLASE → GRUPO → BLOQUE y devuelve arreglos listos para
 * usar en el generador, más una lista de errores/advertencias encontrados.
 * No toca los stores — es una función pura, fácil de testear.
 */
export function parsearTexto(texto: string): ResultadoParseo {
    const clasesResultado: Clase[] = []
    const gruposResultado: Grupo[] = []
    const bloquesResultado: Bloque[] = []
    const errores: ErrorParseo[] = []

    const líneas = texto.split(/\r?\n/)

    let claseActual: Clase | null = null
    let grupoActual: Grupo | null = null
    let contadorGrupoAutomático = 0
    let enParrafoNuevo = true // true justo después de una línea en blanco (o al inicio)

    for (let i = 0; i < líneas.length; i++) {
        const númeroLínea = i + 1
        const líneaCruda = líneas[i]
        const línea = líneaCruda.trim()

        // Línea en blanco: cierra el párrafo actual (el siguiente contenido
        // no-decorativo será una nueva CLASE)
        if (línea === '') {
            enParrafoNuevo = true
            continue
        }

        // Línea decorativa: se ignora, no cambia el estado del párrafo
        if (RE_DECORATIVA.test(línea)) {
            continue
        }

        // ¿Es un BLOQUE?
        const matchBloque = línea.match(RE_BLOQUE)
        if (matchBloque) {
            enParrafoNuevo = false

            if (!claseActual || !grupoActual) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: 'Se encontró un bloque de horario sin una CLASE/GRUPO previamente definidos.',
                })
                continue
            }

            const [, díaCrudo, horaInicio, horaFinal, duraciónDeclarada, ubicación] = matchBloque
            const díaNormalizado = normalizar(díaCrudo)
            const índiceDía = MAPA_DÍAS[díaNormalizado]

            if (índiceDía === undefined) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: `Día inválido: "${díaCrudo}". Días válidos: ${díasSemana.join(', ')}.`,
                })
                continue
            }

            if (!validarHora(horaInicio) || !validarHora(horaFinal)) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: `Formato de hora inválido ("${horaInicio}" o "${horaFinal}"). Se espera HH:MM.`,
                })
                continue
            }

            const índiceInicio = horasInicio.indexOf(horaInicio)
            const índiceFinal = horasFinal.indexOf(horaFinal)

            if (índiceInicio === -1) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: `La hora de inicio "${horaInicio}" no calza con ningún bloque de 50 min del sistema. ` +
                        `Bloque más cercano: ${bloqueMásCercano(horasInicio, horaInicio)}.`,
                })
                continue
            }

            if (índiceFinal === -1) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: `La hora de fin "${horaFinal}" no calza con ningún bloque de 50 min del sistema. ` +
                        `Bloque más cercano: ${bloqueMásCercano(horasFinal, horaFinal)}.`,
                })
                continue
            }

            if (índiceFinal < índiceInicio) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: `El bloque termina (${horaFinal}) antes de empezar (${horaInicio}).`,
                })
                continue
            }

            const duraciónCalculada = índiceFinal - índiceInicio + 1
            const duraciónTexto = Number(duraciónDeclarada)

            if (duraciónCalculada !== duraciónTexto) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: `La duración indicada (${duraciónTexto} horas) no coincide con el rango horario ` +
                        `${horaInicio} - ${horaFinal} (equivale a ${duraciónCalculada} horas). Se usó ${duraciónCalculada}.`,
                })
                // No es fatal: seguimos con la duración calculada (la real, según el rango)
            }

            bloquesResultado.push({
                día: índiceDía,
                inicio: índiceInicio,
                final: índiceFinal,
                id: `idb:${uuid()}`,
                grupo: grupoActual.id,
            })

            // La ubicación (ej. "Sala de Cómputo") no tiene campo propio en el
            // modelo de datos actual (`Bloque` no tiene "ubicación"). La
            // dejamos registrada como advertencia informativa para que se
            // decida manualmente qué hacer con ella (ver notas de uso).
            if (ubicación) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: `Ubicación "${ubicación}" detectada pero el modelo de datos actual (tipo "Bloque") ` +
                        `no tiene un campo para guardarla; se ignoró. Ver sección de notas.`,
                })
            }

            continue
        }

        // ¿Es un GRUPO? (cualquier línea no-bloque, no-decorativa, que no
        // sea la primera del párrafo)
        const matchGrupo = línea.match(RE_GRUPO)

        if (!enParrafoNuevo && claseActual) {
            const [identificador, docente] = matchGrupo
                ? [matchGrupo[1].trim(), matchGrupo[2].trim()]
                : [String.fromCharCode(65 + contadorGrupoAutomático++), línea]

            if (!matchGrupo) {
                errores.push({
                    línea: númeroLínea,
                    contenido: línea,
                    mensaje: `No se encontró "identificador - docente"; se asumió el identificador automático "${identificador}" ` +
                        `y "${línea}" como nombre del docente.`,
                })
            }

            const docenteFinal = docente === '' ? '(Docente por asignar)' : docente

            grupoActual = {
                nombre: `${identificador} - ${docenteFinal}`,
                seleccionado: true,
                id: `idg:${uuid()}`,
                clase: claseActual.id,
            }
            gruposResultado.push(grupoActual)
            continue
        }

        // Si no es bloque ni grupo (o estamos al inicio de un párrafo nuevo) → nueva CLASE
        claseActual = {
            nombre: línea,
            color: colorPara(clasesResultado.length),
            id: `idc:${uuid()}`,
        }
        clasesResultado.push(claseActual)
        grupoActual = null
        contadorGrupoAutomático = 0
        enParrafoNuevo = false
    }

    // Validación de coherencia adicional: clases sin grupos, grupos sin bloques
    for (const clase of clasesResultado) {
        const tieneGrupos = gruposResultado.some(g => g.clase === clase.id)
        if (!tieneGrupos) {
            errores.push({
                línea: -1,
                contenido: clase.nombre,
                mensaje: `La clase "${clase.nombre}" no tiene ningún grupo asociado.`,
            })
        }
    }
    for (const grupo of gruposResultado) {
        const tieneBloques = bloquesResultado.some(b => b.grupo === grupo.id)
        if (!tieneBloques) {
            errores.push({
                línea: -1,
                contenido: grupo.nombre,
                mensaje: `El grupo "${grupo.nombre}" no tiene ningún bloque de horario asociado.`,
            })
        }
    }

    return { clases: clasesResultado, grupos: gruposResultado, bloques: bloquesResultado, errores }
}


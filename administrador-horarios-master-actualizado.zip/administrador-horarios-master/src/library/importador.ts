/**
 * INTEGRACIÓN DEL PARSER CON LOS STORES DEL GENERADOR
 * =====================================================
 *
 * Usa `parsearTexto` (módulo puro, ver `./parser.ts`) y, si el resultado no
 * tiene errores fatales, inserta las clases/grupos/bloques directamente en
 * los stores persistentes (`clases`, `grupos`, `bloques` de `./clases.ts`)
 * que ya usa toda la app (registrador, generador, etc.).
 *
 * Ver `./parser.ts` para el formato de entrada esperado y los supuestos
 * documentados del parser.
 */

import { clases, grupos, bloques } from './clases'
import { agregarNotificación } from './notificaciones'
import { parsearTexto, type ResultadoParseo } from './parser'

export type { ErrorParseo, ResultadoParseo } from './parser'
export { parsearTexto } from './parser'

// ─────────────────────────────── INTEGRACIÓN ───────────────────────────────

export type OpcionesImportación = {
    /** Si es `true`, borra las clases/grupos/bloques existentes antes de importar. Por defecto `false` (se agrega). */
    reemplazar?: boolean
}

/**
 * Parsea el texto y, si no hay errores fatales (bloques sin clase/grupo,
 * días/horas inválidos), inserta el resultado directamente en los stores
 * persistentes que usa toda la app (`clases`, `grupos`, `bloques`).
 *
 * Las advertencias "no fatales" (duración recalculada, ubicación ignorada,
 * clase/grupo vacíos) SÍ se importan, pero se reportan igual para revisión.
 */
export function importarTexto(texto: string, opciones: OpcionesImportación = {}): ResultadoParseo {
    const resultado = parsearTexto(texto)

    const hayErroresFatales = resultado.errores.some(e =>
        e.mensaje.includes('sin una CLASE/GRUPO') ||
        e.mensaje.includes('Día inválido') ||
        e.mensaje.includes('Formato de hora inválido') ||
        e.mensaje.includes('no calza con ningún bloque') ||
        e.mensaje.includes('antes de empezar')
    )

    if (hayErroresFatales) {
        agregarNotificación('error', `Importación cancelada: se encontraron ${resultado.errores.length} problema(s). Revisa el detalle antes de reintentar.`)
        return resultado
    }

    if (opciones.reemplazar) {
        clases.set([])
        grupos.set([])
        bloques.set([])
    }

    clases.set([...clases.get(), ...resultado.clases])
    grupos.set([...grupos.get(), ...resultado.grupos])
    bloques.set([...bloques.get(), ...resultado.bloques])

    const advertencias = resultado.errores.length

    agregarNotificación(
        advertencias > 0 ? 'advertencia' : 'éxito',
        `Se importaron ${resultado.clases.length} clase(s), ${resultado.grupos.length} grupo(s) y ${resultado.bloques.length} bloque(s).` +
        (advertencias > 0 ? ` (${advertencias} advertencia(s), revisa el detalle)` : '')
    )

    return resultado
}

import { persistentAtom } from "@nanostores/persistent";
import { v4 as uuid} from 'uuid'

export const clases = persistentAtom<Clase[]>('v2:clases', [], {
    encode: JSON.stringify,
    decode: JSON.parse,
})

export const grupos = persistentAtom<Grupo[]>('v2:grupos', [], {
    encode: JSON.stringify,
    decode: JSON.parse
})

export const bloques = persistentAtom<Bloque[]>('v2:bloques', [], {
    encode: JSON.stringify,
    decode: JSON.parse
})

// UTILIDADES
export function cambiarColor(idClase: IdClase, nuevoColor: string) {
    const nuevasClases = clases.get()

    const indexClase = nuevasClases.findIndex(clase => clase.id === idClase)

    if (indexClase !== -1) {
        nuevasClases[indexClase].color = nuevoColor
        clases.set([...nuevasClases])
    }
}

export function accionarGrupo(idGrupo: IdGrupo) {
    const nuevosGrupos = grupos.get()

    const indexGrupo = nuevosGrupos.findIndex(grupo => grupo.id === idGrupo)

    if (indexGrupo !== -1) {
        nuevosGrupos[indexGrupo].seleccionado = !nuevosGrupos[indexGrupo].seleccionado

        grupos.set([...nuevosGrupos])
    }
}

// AGREGAR
export function agregarClase() {
    clases.set([...clases.get(), {
        nombre: "",
        color: "#5865f2",
        id: `idc:${uuid()}`
    }])
}

export function agregarGrupo(idClase: IdClase) {
    grupos.set([...grupos.get(), {
        nombre: '',
        id: `idg:${uuid()}`,
        seleccionado: true,
        clase: idClase
    }])
}

export function agregarBloque(idGrupo: IdGrupo) {
    bloques.set([...bloques.get(), {
        día: 0,
        inicio: 0,
        final: 1,
        id: `idb:${uuid()}`,
        grupo: idGrupo,
    }])
}

// ELIMINAR
export function eliminarClase(idClase: IdClase) {
    // Eliminamos los grupos que vinculen a esta clase
    eliminarGrupos(idClase)

    // Colocamos aquellas clases que no tengan la ID de la clase a eliminar
    clases.set([...clases.get().filter(clase => clase.id !== idClase)])
}

function eliminarGrupos(idClase: IdClase) {
    const nuevosGrupos = [...grupos.get()]

    // Por cada grupo con la ID de la clase a eliminar, eliminamos también sus bloques
    nuevosGrupos.filter(grupo => grupo.clase === idClase).forEach(grupo => eliminarBloques(grupo.id))

    // Colocamos aquellos grupos que no tengan la ID de la clase a eliminar
    grupos.set([...nuevosGrupos.filter(grupo => grupo.clase !== idClase)])
}

export function eliminarGrupo(idGrupo: IdGrupo) {
    // Colocamos aquellos grupos que no tengan la ID del grupo a eliminar
    grupos.set([...grupos.get().filter(grupo => grupo.id !== idGrupo)])
}

function eliminarBloques(idGrupo: IdGrupo) {
    // Colocamos aquellos grupos que no tengan la ID del grupo a eliminar
    bloques.set([...bloques.get().filter(bloque => bloque.grupo !== idGrupo)])
}

export function eliminarBloque(idBloque: IdBloque) {
    // Colocamos aquellos grupos que no tengan la ID del bloque a eliminar
    bloques.set([...bloques.get().filter(bloque => bloque.id !== idBloque)])
}

// RENOMBRAR
export function renombrarClase(idClase: IdClase, nuevoNombre:string) {
    const nuevasClases = clases.get()

    const indexClase = nuevasClases.findIndex(clase => clase.id === idClase)

    if (indexClase !== -1) {
        nuevasClases[indexClase].nombre = nuevoNombre

        clases.set([...nuevasClases])
    }
}

export function renombrarGrupo(idGrupo: IdGrupo, nuevoNombre: string) {
    const nuevosGrupos = grupos.get()

    const indexGrupo = nuevosGrupos.findIndex(grupo => grupo.id === idGrupo)

    if (indexGrupo !== -1) {
        nuevosGrupos[indexGrupo].nombre = nuevoNombre

        grupos.set([...nuevosGrupos])
    }
}

export function reprogramarBloque(idBloque: IdBloque, nuevoBloque: Omit<Bloque, 'id'>) {
    const nuevosBloques = bloques.get()

    const indexBloque = nuevosBloques.findIndex(bloque => bloque.id === idBloque)

    if (indexBloque !== -1) {
        nuevosBloques.splice(indexBloque, 1, {...nuevoBloque, id: idBloque})

        bloques.set([...nuevosBloques])
    }
}
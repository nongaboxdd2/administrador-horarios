import { v4 as uuid } from 'uuid'
import { atom, computed } from "nanostores";
import { agregarNotificación } from './notificaciones'
import { persistentAtom } from "@nanostores/persistent";

export const separadores = persistentAtom<Separador[]>('v2:agrupaciones', [{
    nombre: '(No agrupados)',
    id: 'ids:0'
}], {
    encode: JSON.stringify,
    decode: JSON.parse
})

export const horariosFavoritos = persistentAtom<HorarioFavorito[]>('v2:favoritos', [], {
    encode: JSON.stringify,
    decode: JSON.parse
})

export const idHorarioFavoritoVisualizado = atom<IdHorarioFavorito | undefined>()

export const horarioFavoritoVisualizado = computed([horariosFavoritos, idHorarioFavoritoVisualizado], ($horariosFavoritos, $idHorarioFavoritoVisualizado) => {
    if (!$idHorarioFavoritoVisualizado) return []

    const cursos = $horariosFavoritos.find(horarioFavorito => horarioFavorito.id === $idHorarioFavoritoVisualizado)?.cursos

    if (!cursos) return []

    return cursos
})

// SEPARADORES
export function agregarSeparador() {
    const nuevosSeparadores = separadores.get()

    nuevosSeparadores.splice(nuevosSeparadores.length - 1, 0, { nombre: '', id: `ids:${uuid()}` })

    separadores.set([...nuevosSeparadores])
}

export function renombrarSeparador(nuevoNombre: string, idSeparador: IdSeparador) {
    const nuevosSeparadores = separadores.get()

    const indexSeparador = nuevosSeparadores.findIndex(separador => separador.id === idSeparador)

    if (indexSeparador !== -1) {
        nuevosSeparadores[indexSeparador].nombre = nuevoNombre

        separadores.set([...nuevosSeparadores])
    }
}

export function eliminarSeparador(idSeparador: IdSeparador) {
    separadores.set([...separadores.get().filter(separador => separador.id !== idSeparador)])

    eliminarHorarios(idSeparador)
}

// HORARIOS
export function agregarHorario(cursos: readonly Curso[]) {
    horariosFavoritos.set([...horariosFavoritos.get(), { separador: 'ids:0', id: `idf:${uuid()}`, cursos }])
    agregarNotificación("éxito", "Horario marcado como favorito")
}

function eliminarHorarios(idSeparador: IdSeparador) {
    horariosFavoritos.set([...horariosFavoritos.get().filter(horario => horario.separador !== idSeparador)])
    agregarNotificación("éxito", "Horario favorito eliminado")
}

export function eliminarHorario(idHorarioFavorito: IdHorarioFavorito) {
    horariosFavoritos.set([...horariosFavoritos.get().filter(horario => horario.id !== idHorarioFavorito)])
}

export function mostrarHorario(idHorarioFavorito: IdHorarioFavorito) {
    idHorarioFavoritoVisualizado.set(idHorarioFavorito)
}

export function moverHorario(idHorarioFavorito: IdHorarioFavorito, idSeparadorDestino: IdSeparador) {
    const nuevosHorariosFavoritos = horariosFavoritos.get()

    const indexHorarioFavorito = nuevosHorariosFavoritos.findIndex(horario => horario.id === idHorarioFavorito)

    if (indexHorarioFavorito !== -1) {
        nuevosHorariosFavoritos[indexHorarioFavorito].separador = idSeparadorDestino

        horariosFavoritos.set([...nuevosHorariosFavoritos])
    }
}
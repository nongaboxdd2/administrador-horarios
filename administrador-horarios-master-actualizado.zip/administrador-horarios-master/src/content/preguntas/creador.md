---
pregunta: "¿Quién creó esta página?"
orden: 1
---
Me llamo "Juan Quispe Huillca", estudiante de la **Escuela Profesional de Ingeniería Industrial** de la [**Universidad Nacional de San Agustín**](https://www.unsa.edu.pe/) y miembro del [**Centro de Documentación de Ingeniería Industrial**](https://web.facebook.com/cendii.unsa).
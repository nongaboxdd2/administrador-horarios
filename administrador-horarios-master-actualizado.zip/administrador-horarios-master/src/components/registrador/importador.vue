<template>
    <div class="p-2 border-b-2 border-white-dark dark:border-black-light">
        <div v-if="!abierto" class="flex justify-end">
            <Button @click="abierto = true">Importar texto</Button>
        </div>
        <div v-else class="flex flex-col gap-2">
            <textarea
                v-model="texto"
                rows="10"
                placeholder="Pega aquí el texto CLASE / GRUPO / BLOQUE..."
                class="w-full p-2 rounded-md font-mono text-sm bg-white dark:bg-black border-2 border-white-dark dark:border-black-light"
            />
            <div class="flex flex-wrap gap-2 items-center">
                <Button @click="ejecutar">Importar</Button>
                <Button @click="abierto = false; texto = ''; errores = []">Cancelar</Button>
                <label class="flex items-center gap-1 text-sm">
                    <input type="checkbox" v-model="reemplazar" />
                    Reemplazar datos existentes
                </label>
            </div>
            <div v-if="errores.length > 0" class="text-sm max-h-40 overflow-y-auto bg-white-dark dark:bg-black-light rounded-md p-2">
                <p class="font-bold">Detalle ({{ errores.length }}):</p>
                <ul class="list-disc pl-5">
                    <li v-for="error in errores">
                        <span v-if="error.línea > 0">Línea {{ error.línea }}: </span>{{ error.mensaje }}
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { ref } from 'vue'
    import Button from '../etiquetas/button.vue'
    import { importarTexto, type ErrorParseo } from '@Librería/importador'

    const abierto = ref(false)
    const texto = ref('')
    const reemplazar = ref(false)
    const errores = ref<ErrorParseo[]>([])

    function ejecutar() {
        const resultado = importarTexto(texto.value, { reemplazar: reemplazar.value })
        errores.value = resultado.errores

        // Si no hubo errores fatales (la importación sí insertó datos), cerramos y limpiamos
        if (resultado.clases.length > 0) {
            texto.value = ''
        }
    }
</script>

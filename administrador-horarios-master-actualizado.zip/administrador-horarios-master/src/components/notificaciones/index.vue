<template>
    <div class="absolute w-full sm:w-3/4 md:w-1/2 lg:w-2/5 xl:w-1/4 right-0 bottom-0 p-3 flex flex-col items-end gap-3">
        <div v-for="notificacion in $notificaciones" :key="notificacion.id" class="w-full sm:w-fit relative flex flex-row">
            <div :class="`p-2 rounded-l-md
                ${(notificacion.tipo === 'error') ? 'bg-error' : ''}
                ${(notificacion.tipo === 'éxito') ? 'bg-success text-black' : ''}
                ${(notificacion.tipo === 'advertencia') ? 'bg-warning text-black' : ''}
            `">
                <IconExclamationCircle v-if="notificacion.tipo === 'error'" />
                <IconCircleCheck v-else-if="notificacion.tipo === 'éxito'" />
                <IconAlertTriangle v-else />
            </div>
            <div :class="`p-2 rounded-r-md
                ${(notificacion.tipo === 'error') ? 'bg-error-light' : ''}
                ${(notificacion.tipo === 'éxito') ? 'bg-success-light text-black' : ''}
                ${(notificacion.tipo === 'advertencia') ? 'bg-warning-light text-black' : ''}
            `">
                <p>{{ notificacion.mensaje }}</p>
            </div>
            <button class="absolute max-sm:text-lg translate-x-1/2 -translate-y-1/2 font-bold right-0 top-0 bg-black text-white rounded-full px-2" @click="eliminarNotificacion(notificacion.id)">X</button>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { IconExclamationCircle, IconAlertTriangle, IconCircleCheck } from "@tabler/icons-vue";
    import { notificaciones, eliminarNotificacion } from "@Librería/notificaciones"
    import { useStore } from '@nanostores/vue';
    
    const $notificaciones = useStore(notificaciones)
</script>
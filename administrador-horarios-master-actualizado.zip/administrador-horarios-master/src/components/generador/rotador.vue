<template>
    <button @click="rotarÍndice('anterior')" :disabled="$horariosGenerados.length <= 1">
        <IconArrowBadgeLeft v-if="$horariosGenerados.length <= 1" stroke-width="1" />
        <IconArrowBadgeLeftFilled v-else />
    </button>
    <p class="font-bold" v-if="$horariosGenerados.length > 0">{{ $índiceGenerador + 1 }} / {{ $horariosGenerados.length }}</p>
    <p v-else>0 / 0</p>
    <button @click="rotarÍndice('siguiente')" :disabled="$horariosGenerados.length <= 1">
        <IconArrowBadgeRight v-if="$horariosGenerados.length <= 1" stroke-width="1" />
        <IconArrowBadgeRightFilled v-else />
    </button>
</template>

<script setup lang="ts">
    import { IconArrowBadgeLeft, IconArrowBadgeLeftFilled, IconArrowBadgeRight, IconArrowBadgeRightFilled } from '@tabler/icons-vue'
    import { horariosGenerados, índiceGenerador, rotarÍndice } from '@Librería/horarios'
    import { useStore } from '@nanostores/vue';

    const $horariosGenerados = useStore(horariosGenerados)
    const $índiceGenerador = useStore(índiceGenerador)
</script>
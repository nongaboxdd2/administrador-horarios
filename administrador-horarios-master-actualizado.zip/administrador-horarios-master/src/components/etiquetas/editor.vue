<template>
    <div class="flex flex-row items-center">
        <span v-if="texto.trim() === ''" class="italic" @dblclick="emit('editar')">(Vacío)</span>
        <span v-else @dblclick="emit('editar')" class="pr-2">{{ texto }}</span>
        <div class="relative">
            <div class="flex flex-row gap-1 absolute -translate-y-1/2">
                <button v-for="opcion in opciones.filter(op => op !== 'pintar') as Exclude<Emits, 'pintar'>[]"
                    class="hidden [&_svg]:h-[1.25rem] [&_svg]:w-[1.25rem]"
                    @click="emit(opcion)">
                    <component :is="iconos[opcion]" />
                </button>
                <button v-if="opciones.includes('pintar')" class="hidden">
                    <label class="cursor-pointer">
                        <div class="[&_svg]:h-[1.25rem] [&_svg]:w-[1.25rem]">
                            <IconPalette />
                        </div>
                        <input class="hidden" type="color" :value="color" @change="emit('pintar', ($event.target as HTMLInputElement).value)" />
                    </label>
                </button>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { IconPencil, IconTrash, IconPalette, IconEye, type SVGProps } from "@tabler/icons-vue"
    import type { FunctionalComponent } from "vue"

    type Emits = 'editar' | 'eliminar' | 'visualizar' | 'pintar'

    const iconos: Record<Exclude<Emits, 'pintar'>, FunctionalComponent<SVGProps>> = {
        editar: IconPencil,
        eliminar: IconTrash,
        visualizar: IconEye
    }

    const { texto, opciones, color = '#000' } = defineProps<{
        texto: string,
        opciones: Emits[],
        color?: string
    }>()
    
    const emit = defineEmits<{
        (e: Exclude<Emits, 'pintar'>): void,
        (e: 'pintar', valor: string): void 
    }>()
</script>

<style is:inline>
    .icono svg {
        height: 1rem;
        width: 1rem;
    }
</style>
<template>
    <button class="italic flex items-center gap-2 p-2" @click="emit('click')">
        <span class="icono">
            <IconNewSection />
        </span>
        <span>
            <slot></slot>
        </span>
    </button>
</template>

<script setup lang="ts">
    import { IconNewSection } from "@tabler/icons-vue";

    const emit = defineEmits<{
        (e: 'click'): void
    }>()
</script>